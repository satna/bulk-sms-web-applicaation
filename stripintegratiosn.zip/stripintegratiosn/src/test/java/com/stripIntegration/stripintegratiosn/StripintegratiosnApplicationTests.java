package com.stripIntegration.stripintegratiosn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripintegratiosnApplicationTests {

	@Test
	void contextLoads() {
	}

}
