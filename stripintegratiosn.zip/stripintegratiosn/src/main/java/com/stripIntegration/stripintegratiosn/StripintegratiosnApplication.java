package com.stripIntegration.stripintegratiosn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StripintegratiosnApplication {

	public static void main(String[] args) {
		SpringApplication.run(StripintegratiosnApplication.class, args);
	}

}
